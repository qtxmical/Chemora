import { useEffect } from 'react';
import { useParams, useLocation, Link } from 'wouter';
import { ArrowLeft, Activity, Zap, BookOpen, Leaf } from 'lucide-react';
import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';

// Define the data for the research areas
const areaData: Record<string, any> = {
  'biomolecular': {
    title: 'Biomolecular Engineering',
    icon: Activity,
    color: 'from-blue-500/20 to-blue-500/5',
    accentColor: 'text-blue-500',
    description: "Our biomolecular engineering program focuses on the intersection of chemical engineering principles and biological systems. By leveraging advanced synthetic biology, metabolic engineering, and structural biology, our researchers are developing next-generation therapeutics, targeted drug delivery systems, and novel biosensors.\n\nWe collaborate closely with medical institutions and biotech leaders to ensure our innovations translate rapidly from the lab bench to clinical applications, addressing critical challenges in global healthcare.",
    keyAreas: [
      "Targeted Drug Delivery Systems",
      "Synthetic Biology & Metabolic Engineering",
      "Tissue Engineering & Regenerative Medicine"
    ]
  },
  'sustainable-energy': {
    title: 'Sustainable Energy',
    icon: Zap,
    color: 'from-amber-500/20 to-amber-500/5',
    accentColor: 'text-amber-500',
    description: "The transition to a sustainable energy future is one of the most pressing challenges of our time. Our research in sustainable energy develops highly efficient catalytic processes, next-generation battery architectures, and advanced fuel cells.\n\nThrough multiscale modeling and state-of-the-art operando characterization, we aim to optimize energy storage and conversion technologies, reducing dependence on fossil fuels and mitigating the impacts of climate change.",
    keyAreas: [
      "Advanced Battery Technologies",
      "Hydrogen Fuel Cells & Electrocatalysis",
      "Solar Energy Conversion & Storage"
    ]
  },
  'advanced-materials': {
    title: 'Advanced Materials',
    icon: BookOpen,
    color: 'from-purple-500/20 to-purple-500/5',
    accentColor: 'text-purple-500',
    description: "Advanced materials are the foundation of modern technological progress. Our department pioneers the design, synthesis, and characterization of novel polymers, nanomaterials, and smart surfaces tailored for specific, high-performance applications.\n\nBy manipulating matter at the molecular and nanoscale levels, we create materials with unprecedented electronic, optical, and mechanical properties, driving innovations in electronics, aerospace, and consumer products.",
    keyAreas: [
      "Nanomaterial Synthesis & Characterization",
      "Smart & Responsive Polymers",
      "Thin Films & Surface Engineering"
    ]
  },
  'environmental-technology': {
    title: 'Environmental Technology',
    icon: Leaf,
    color: 'from-emerald-500/20 to-emerald-500/5',
    accentColor: 'text-emerald-500',
    description: "Protecting our environment requires robust, scalable engineering solutions. Our environmental technology researchers are at the forefront of developing advanced water purification membranes, carbon capture methodologies, and waste valorization processes.\n\nWe employ life cycle assessments and process intensification strategies to ensure that our environmental solutions are both ecologically impactful and economically viable for industrial adoption.",
    keyAreas: [
      "Membrane Technologies for Water Purification",
      "Carbon Capture & Utilization",
      "Waste-to-Energy & Resource Recovery"
    ]
  }
};

export default function ResearchArea() {
  const params = useParams();
  const slug = params.slug || '';
  const data = areaData[slug];

  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  if (!data) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center">
        <h1 className="text-3xl font-bold mb-4">Research area not found</h1>
        <Link href="/" className="text-primary hover:underline">Return to Home</Link>
      </div>
    );
  }

  const Icon = data.icon;

  return (
    <main className="relative min-h-screen flex flex-col w-full overflow-x-hidden bg-background">
      <Navbar />
      
      {/* Banner */}
      <section className={`pt-32 pb-20 bg-gradient-to-b ${data.color} border-b border-border/50 relative overflow-hidden`}>
        <div className="container mx-auto px-4 md:px-6 relative z-10">
          <div className="mb-8">
            <Link href="/" className="inline-flex items-center text-sm font-medium text-muted-foreground hover:text-foreground transition-colors bg-background/50 px-3 py-1.5 rounded-full backdrop-blur-md border border-border">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Home
            </Link>
          </div>
          
          <div className="flex items-center gap-4 mb-6">
            <div className={`w-16 h-16 rounded-2xl bg-background/50 backdrop-blur-md flex items-center justify-center ${data.accentColor} shadow-sm border border-border/50`}>
              <Icon className="w-8 h-8" />
            </div>
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold font-heading tracking-tight">
              {data.title}
            </h1>
          </div>
        </div>
      </section>

      {/* Content */}
      <section className="py-20">
        <div className="container mx-auto px-4 md:px-6">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-16">
            
            {/* Main Text */}
            <div className="lg:col-span-7 space-y-8">
              <div>
                <h2 className="text-2xl font-bold font-heading mb-6">Overview</h2>
                <div className="space-y-4 text-muted-foreground text-lg leading-relaxed whitespace-pre-wrap">
                  {/* REPLACE: Longer placeholder text handling */}
                  {data.description}
                </div>
              </div>

              {/* Image Grid Placeholder */}
              <div className="grid grid-cols-2 gap-4 mt-12">
                <div className="aspect-square rounded-2xl bg-muted border-2 border-dashed border-border flex items-center justify-center p-6 text-center text-muted-foreground">
                  // REPLACE: Insert related lab image 1
                </div>
                <div className="aspect-square rounded-2xl bg-muted border-2 border-dashed border-border flex items-center justify-center p-6 text-center text-muted-foreground">
                  // REPLACE: Insert related lab image 2
                </div>
              </div>
            </div>

            {/* Sidebar: Key Areas */}
            <div className="lg:col-span-5">
              <div className="glass-panel p-8 rounded-3xl sticky top-32">
                <h3 className="text-xl font-bold font-heading mb-6">Key Research Areas</h3>
                <div className="space-y-4">
                  {data.keyAreas.map((area: string, idx: number) => (
                    <div key={idx} className="flex items-start gap-4 p-4 rounded-2xl bg-background/50 border border-border/50">
                      <div className={`w-8 h-8 rounded-full bg-muted flex items-center justify-center flex-shrink-0 ${data.accentColor}`}>
                        <span className="font-bold text-sm">{idx + 1}</span>
                      </div>
                      <div>
                        <h4 className="font-semibold">{area}</h4>
                        <p className="text-sm text-muted-foreground mt-1">
                          {/* REPLACE: Short description of the sub-area */}
                          Exploring advanced methodologies to solve complex engineering challenges within this domain.
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
                
                <div className="mt-8 pt-8 border-t border-border/50">
                  <h4 className="font-semibold mb-4">Interested in joining our lab?</h4>
                  <a href="#" className="w-full inline-flex items-center justify-center rounded-xl bg-primary px-5 py-3 text-sm font-medium text-primary-foreground hover:bg-primary/90 transition-all">
                    Contact Faculty Lead
                  </a>
                </div>
              </div>
            </div>

          </div>
        </div>
      </section>

      <Footer />
    </main>
  );
}