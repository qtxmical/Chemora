import Navbar from '@/components/Navbar';
import Hero from '@/components/Hero';
import About from '@/components/About';
import AboutExtras from '@/components/AboutExtras';
import Cards from '@/components/Cards';
import Gallery from '@/components/Gallery';
import Testimonials from '@/components/Testimonials';
import FAQ from '@/components/FAQ';
import References from '@/components/References';
import Footer from '@/components/Footer';
import ScrollToTop from '@/components/ScrollToTop';
import ThemeCustomizer from '@/components/ThemeCustomizer';

export default function Home() {
  return (
    <main className="relative min-h-screen flex flex-col w-full overflow-x-hidden">
      <Navbar />
      <Hero />
      <About />
      <AboutExtras />
      <Cards />
      <Gallery />
      <Testimonials />
      <FAQ />
      <References />
      <Footer />
      <ScrollToTop />
      <ThemeCustomizer />
    </main>
  );
}
