import { useEffect } from 'react';
import { Link } from 'wouter';
import { ArrowLeft } from 'lucide-react';
import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';
import Universities from '@/components/Universities';

export default function UniversitiesPage() {
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  return (
    <main className="relative min-h-screen flex flex-col w-full overflow-x-hidden bg-background">
      <Navbar />
      
      {/* Banner */}
      <section className="pt-32 pb-16 bg-gradient-to-b from-primary/10 to-transparent border-b border-border/50 relative overflow-hidden">
        <div className="container mx-auto px-4 md:px-6 relative z-10">
          <div className="mb-8">
            <Link href="/" className="inline-flex items-center text-sm font-medium text-muted-foreground hover:text-foreground transition-colors bg-background/50 px-3 py-1.5 rounded-full backdrop-blur-md border border-border">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Home
            </Link>
          </div>
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold font-heading tracking-tight">
            Where to Study Chemical Engineering
          </h1>
        </div>
      </section>

      {/* Content */}
      <Universities />

      <Footer />
    </main>
  );
}