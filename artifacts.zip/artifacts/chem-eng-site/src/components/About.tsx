import { motion } from 'framer-motion';
import { Microscope, FlaskConical, GraduationCap, Atom } from 'lucide-react';

export default function About() {
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2,
      },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.6 } },
  };

  return (
    <section id="about" className="py-24 relative overflow-hidden">
      <div className="container mx-auto px-4 md:px-6">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          
          {/* Left Column: Image/Visual Placeholder */}
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true, margin: "-100px" }}
            transition={{ duration: 0.8 }}
            className="relative"
          >
            {/* REPLACE: Swap this styled div with an actual <img> tag for the facility or lab */}
            <div className="aspect-[4/5] rounded-3xl overflow-hidden glass-panel relative group">
              <div className="absolute inset-0 bg-gradient-to-br from-primary/20 to-accent/20 mix-blend-overlay group-hover:scale-105 transition-transform duration-700"></div>
              
              {/* Decorative abstract art acting as image placeholder */}
              <div className="absolute inset-0 flex items-center justify-center bg-muted/30">
                <div className="text-center p-8">
                  <Microscope className="w-24 h-24 mx-auto text-primary/40 mb-4" />
                  <p className="text-muted-foreground font-medium text-lg border border-dashed border-muted-foreground/30 rounded-xl p-4">
                    Laboratory Image Placeholder<br/>
                    <span className="text-sm font-normal">Replace with actual facility photo</span>
                  </p>
                </div>
              </div>
            </div>
            
            {/* Floating stat card */}
            <motion.div 
              initial={{ y: 20, opacity: 0 }}
              whileInView={{ y: 0, opacity: 1 }}
              viewport={{ once: true }}
              transition={{ delay: 0.5, duration: 0.6 }}
              className="absolute -bottom-8 -right-8 glass-panel p-6 rounded-2xl shadow-xl border-t border-white/20 dark:border-white/5"
            >
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-full bg-accent/20 flex items-center justify-center text-accent">
                  <GraduationCap className="w-6 h-6" />
                </div>
                <div>
                  <div className="text-3xl font-bold font-heading">+6</div>
                  <div className="text-sm text-muted-foreground">Industriyang Saklaw</div>
                </div>
              </div>
            </motion.div>
          </motion.div>

          {/* Right Column: Text Content */}
          <motion.div
            variants={containerVariants}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-100px" }}
          >
            <motion.div variants={itemVariants} className="mb-2">
              <span className="text-primary font-semibold tracking-wider uppercase text-sm">About The Department</span>
            </motion.div>
            
            <motion.h2 variants={itemVariants} className="text-4xl md:text-5xl font-bold font-heading mb-6 leading-tight">
              {/* REPLACE: Update section heading */}Ano ang Chemical Engineering?</motion.h2>
            
            <motion.p variants={itemVariants} className="text-lg text-muted-foreground mb-8 leading-relaxed">
              {/* REPLACE: Update body paragraph */}Ang Chemical Engineering ay sangay ng inhinyeriya na gumagamit ng mga prinsipyo ng kimika, pisika, matematika, at biyolohiya upang magdisenyo, magpaunlad, at mamahala ng mga proseso na nagko-convert ng hilaw na materyales tungo sa mga produktong kapaki-pakinabang. Layunin nitong lumikha ng mga prosesong ligtas, episyente, matipid, at napapanatili para sa iba't ibang industriya.</motion.p>
            
            <motion.div variants={containerVariants} className="space-y-6">
              {/* Feature 1 */}
              <motion.div variants={itemVariants} className="flex gap-4">
                <div className="flex-shrink-0 w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center text-primary">
                  <FlaskConical className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="text-xl font-bold font-heading mb-2">Papel at Kasanayan ng Isang Chemical Engineer</h3>
                  <p className="text-muted-foreground">Ang mga Chemical Engineer ay lumilikha at nagpapahusay ng mga proseso upang gawing kapaki-pakinabang na produkto ang mga hilaw na materyales. Ginagamit nila ang agham, matematika, at teknolohiya upang magsuri ng problema at bumuo ng episyente at ligtas na solusyon. Upang maisagawa ito, kinakailangan ang matibay na kasanayan sa kritikal na pag-iisip, pagsusuri ng datos, paglutas ng suliranin, pagkamalikhain, at pakikipagtulungan.</p>
                </div>
              </motion.div>
              
              {/* Feature 2 */}
              <motion.div variants={itemVariants} className="flex gap-4">
                <div className="flex-shrink-0 w-12 h-12 rounded-xl bg-accent/10 flex items-center justify-center text-accent">
                  <Atom className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="text-xl font-bold font-heading mb-2">Saklaw at Kahalagahan ng Chemical Engineering</h3>
                  <p className="text-muted-foreground">Malawak ang saklaw ng Chemical Engineering sa iba't ibang industriya, kabilang ang pagkain at inumin, parmasya, petrolyo at enerhiya, pagmamanupaktura, water treatment, at pangangalaga sa kapaligiran. Sa pamamagitan ng pagbuo ng mga makabago at napapanatiling proseso, nakatutulong ang mga Chemical Engineer sa pagpapabuti ng kalidad ng buhay, pag-unlad ng industriya, at pangangalaga sa kalikasan.</p>
                </div>
              </motion.div>
            </motion.div>
            
          </motion.div>
        </div>
      </div>
    </section>
  );
}
