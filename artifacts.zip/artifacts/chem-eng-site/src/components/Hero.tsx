import { motion, useScroll, useTransform } from 'framer-motion';
import { ArrowRight, Beaker, Atom, FlaskConical } from 'lucide-react';
import { useRef } from 'react';

export default function Hero() {
  const containerRef = useRef(null);
  const { scrollYProgress } = useScroll({
    target: containerRef,
    offset: ["start start", "end start"]
  });

  const y1 = useTransform(scrollYProgress, [0, 1], [0, 200]);
  const y2 = useTransform(scrollYProgress, [0, 1], [0, -150]);
  const opacity = useTransform(scrollYProgress, [0, 0.8], [1, 0]);

  return (
    <section 
      id="home" 
      ref={containerRef}
      className="relative min-h-[100dvh] flex items-center justify-center overflow-hidden pt-20"
    >
      {/* Background abstract elements */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        {/* Subtle grid pattern */}
        <div className="absolute inset-0 bg-[linear-gradient(to_right,#80808012_1px,transparent_1px),linear-gradient(to_bottom,#80808012_1px,transparent_1px)] bg-[size:4rem_4rem] [mask-image:radial-gradient(ellipse_60%_50%_at_50%_0%,#000_70%,transparent_100%)]"></div>
        
        {/* Floating shapes */}
        <motion.div 
          style={{ y: y1 }}
          className="absolute top-[20%] left-[10%] w-64 h-64 bg-primary/10 rounded-full blur-3xl"
        />
        <motion.div 
          style={{ y: y2 }}
          className="absolute bottom-[10%] right-[10%] w-80 h-80 bg-accent/10 rounded-full blur-3xl"
        />
        
        {/* Chemical/Molecular SVG decorations */}
        <motion.div
          animate={{ rotate: 360 }}
          transition={{ duration: 120, repeat: Infinity, ease: "linear" }}
          className="absolute -top-32 -right-32 text-primary/5 opacity-50"
        >
          {/* Hexagon lattice placeholder */}
          <svg width="600" height="600" viewBox="0 0 100 100" fill="none" stroke="currentColor" strokeWidth="0.5">
            <path d="M50 0 L93.3 25 L93.3 75 L50 100 L6.7 75 L6.7 25 Z" />
            <path d="M50 30 L73.3 43.5 L73.3 70.5 L50 84 L26.7 70.5 L26.7 43.5 Z" />
          </svg>
        </motion.div>
      </div>
      <motion.div 
        style={{ opacity }}
        className="container mx-auto px-4 md:px-6 relative z-10"
      >
        <div className="max-w-4xl mx-auto text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.1 }}
            className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full glass-panel text-sm font-medium text-primary mb-8 border-primary/20"
          >
            <Atom className="w-4 h-4" />
            <span>Inhinyeriya para sa Kinabukasan</span>
          </motion.div>
          
          <motion.h1 
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2, ease: [0.2, 0.65, 0.3, 0.9] }}
            className="text-5xl md:text-7xl lg:text-8xl font-bold font-heading tracking-tight mb-6"
          >
            {/* REPLACE: Update the hero title here */}
            Mula Agham <br className="hidden md:block" />
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary to-accent">
              Tungo Sa Pagbabago
            </span>
          </motion.h1>
          
          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.4 }}
            className="text-lg md:text-xl text-muted-foreground mb-10 max-w-2xl mx-auto font-body"
          >
            {/* REPLACE: Update the subtitle here */}Tuklasin ang Chemical Engineering, isang kursong pinagsasama ang agham at inobasyon upang makabuo ng mga ligtas, episyente, at napapanatiling solusyon para sa iba't ibang industriya.</motion.p>
          
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.6 }}
            className="flex flex-col sm:flex-row items-center justify-center gap-4"
          >
            <a 
              href="#programs" 
              className="w-full sm:w-auto inline-flex items-center justify-center gap-2 rounded-xl bg-primary px-8 py-4 text-base font-medium text-primary-foreground hover:bg-primary/90 shadow-lg shadow-primary/25 transition-all hover:-translate-y-1"
            >
              {/* REPLACE: Primary CTA Text */}
              Explore Programs
              <ArrowRight className="w-4 h-4" />
            </a>
            <a 
              href="#research" 
              className="w-full sm:w-auto inline-flex items-center justify-center gap-2 rounded-xl border border-input bg-background/50 backdrop-blur-sm px-8 py-4 text-base font-medium text-foreground hover:bg-accent/10 hover:text-accent-foreground hover:border-accent/50 transition-all"
            >
              {/* REPLACE: Secondary CTA Text */}
              Our Research
              <Beaker className="w-4 h-4" />
            </a>
          </motion.div>
        </div>
      </motion.div>
      {/* Scroll indicator */}
      <motion.div 
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1.2, duration: 1 }}
        className="absolute bottom-10 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2"
      >
        <span className="text-xs uppercase tracking-widest text-muted-foreground font-medium">Scroll</span>
        <div className="w-px h-12 bg-gradient-to-b from-muted-foreground/50 to-transparent"></div>
      </motion.div>
    </section>
  );
}
