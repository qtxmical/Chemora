import { motion } from 'framer-motion';
import { Maximize2 } from 'lucide-react';

export default function Gallery() {
  // REPLACE: Update gallery images
  const images = [
    { id: 1, caption: 'Advanced Polymer Research Lab', colSpan: 'col-span-1 md:col-span-2' },
    { id: 2, caption: 'Student Working on Distillation Column', colSpan: 'col-span-1' },
    { id: 3, caption: 'Microscopy Facility', colSpan: 'col-span-1' },
    { id: 4, caption: 'Annual Research Symposium', colSpan: 'col-span-1' },
    { id: 5, caption: 'Process Engineering Control Room', colSpan: 'col-span-1 md:col-span-2' },
  ];

  return (
    <section id="gallery" className="py-24 bg-muted/30">
      <div className="container mx-auto px-4 md:px-6">
        <div className="flex flex-col md:flex-row justify-between items-end mb-12 gap-6">
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
            className="max-w-2xl"
          >
            <span className="text-primary font-semibold tracking-wider uppercase text-sm">Facilities & Life</span>
            <h2 className="text-4xl font-bold font-heading mt-2">Department Gallery</h2>
          </motion.div>
          <motion.a
            initial={{ opacity: 0, x: 20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
            href="#"
            className="inline-flex items-center text-primary font-medium hover:text-accent transition-colors"
          >
            View full gallery
            <svg className="w-4 h-4 ml-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 8l4 4m0 0l-4 4m4-4H3" />
            </svg>
          </motion.a>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 auto-rows-[250px]">
          {images.map((image, index) => (
            <motion.div
              key={image.id}
              initial={{ opacity: 0, scale: 0.95 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              className={`relative group overflow-hidden rounded-2xl ${image.colSpan}`}
            >
              {/* REPLACE: Swap this styled div with an actual <img> tag */}
              <div className="absolute inset-0 bg-gradient-to-br from-primary/10 to-accent/10 flex items-center justify-center border border-border/50">
                <div className="text-muted-foreground/50 text-sm font-medium">Image {image.id}</div>
              </div>
              
              {/* Overlay */}
              <div className="absolute inset-0 bg-gradient-to-t from-background/90 via-background/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
              
              <div className="absolute inset-0 p-6 flex flex-col justify-end translate-y-4 group-hover:translate-y-0 opacity-0 group-hover:opacity-100 transition-all duration-300">
                <div className="flex justify-between items-end">
                  <p className="text-foreground font-medium max-w-[80%]">{image.caption}</p>
                  <button className="w-10 h-10 rounded-full glass-panel flex items-center justify-center text-foreground hover:text-primary transition-colors">
                    <Maximize2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
