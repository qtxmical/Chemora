import { motion } from 'framer-motion';

export default function Timeline() {
  // REPLACE: Update timeline events
  const events = [
    {
      year: '1921',
      title: 'Pagsilang ng Chemical Engineering Profession',
      description: 'Nagsimula ang pagkilala sa Chemical Engineering bilang isang opisyal na propesyon sa Pilipinas.',
    },
    {
      year: '1939',
      title: 'Itinatag ang PIChE',
      description: 'Binuo ang PIChE upang pag-isahin at itaguyod ang mga chemical engineer sa bansa.',
    },
    {
      year: '1948',
      title: 'Naipasa ang Chemical Engineering Law',
      description: 'Itinakda ng batas ang mga pamantayan para sa edukasyon at pagsasanay ng mga ChE.',
    },
    {
      year: '1950s',
      title: 'Lumawak ang ChE Education',
      description: 'Dumami ang mga unibersidad na nag-aalok ng Chemical Engineering program.',
    },
    {
      year: 'Kasalukuyan',
      title: 'ChE para sa Kinabukasan',
      description: 'Patuloy na nagbibigay ang mga chemical engineer ng solusyon sa industriya at sustainability.',
    },
  ];

  return (
    <section id="timeline" className="py-24 relative overflow-hidden">
      <div className="container mx-auto px-4 md:px-6">
        <div className="text-center max-w-2xl mx-auto mb-20">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
          >
            <span className="text-primary font-semibold tracking-wider uppercase text-sm">Our Legacy</span>
            <h2 className="text-4xl font-bold font-heading mt-2 mb-4">Kasaysayan ng Chemical Engineering sa Pilipinas</h2>
            <p className="text-muted-foreground text-lg">
              {/* REPLACE: Update description */}Sa mahigit isang siglo, patuloy na umuunlad ang Chemical Engineering sa Pilipinas, mula sa pagtatatag ng propesyon hanggang sa paghubog ng mga inobasyong nagbibigay-solusyon sa industriya at lipunan.</p>
          </motion.div>
        </div>

        <div className="relative max-w-4xl mx-auto">
          {/* Vertical Line */}
          <div className="absolute left-[20px] md:left-1/2 top-0 bottom-0 w-px bg-border -translate-x-1/2"></div>
          
          {events.map((event, index) => {
            const isEven = index % 2 === 0;
            return (
              <motion.div 
                key={index}
                initial={{ opacity: 0, y: 50 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-100px" }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                className="relative flex items-center justify-between mb-16 last:mb-0"
              >
                {/* Mobile layout keeps everything on right. Desktop alternates left/right. */}
                <div className={`hidden md:block w-5/12 ${isEven ? 'text-right pr-12' : 'order-last pl-12'}`}>
                  {isEven ? (
                    <>
                      <div className="text-4xl font-bold font-heading text-primary/20 mb-2">{event.year}</div>
                      <h3 className="text-xl font-bold font-heading mb-2">{event.title}</h3>
                      <p className="text-muted-foreground">{event.description}</p>
                    </>
                  ) : (
                    <>
                      <div className="text-4xl font-bold font-heading text-primary/20 mb-2">{event.year}</div>
                      <h3 className="text-xl font-bold font-heading mb-2">{event.title}</h3>
                      <p className="text-muted-foreground">{event.description}</p>
                    </>
                  )}
                </div>

                {/* Mobile content block */}
                <div className="w-full md:hidden pl-16 pr-4 relative">
                  <div className="text-3xl font-bold font-heading text-primary/20 mb-1">{event.year}</div>
                  <h3 className="text-lg font-bold font-heading mb-2">{event.title}</h3>
                  <p className="text-muted-foreground text-sm">{event.description}</p>
                </div>

                {/* Center Node */}
                <div className="absolute left-[20px] md:left-1/2 -translate-x-1/2 w-4 h-4 rounded-full bg-primary border-4 border-background z-10 shadow-[0_0_0_4px_hsl(var(--primary)/0.2)]"></div>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
