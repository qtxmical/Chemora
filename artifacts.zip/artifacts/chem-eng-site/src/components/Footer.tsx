import { Hexagon, MapPin, Phone, Mail, Github, Twitter, Linkedin, Youtube } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="bg-background border-t border-border pt-16 pb-8 relative overflow-hidden">
      {/* Decorative top border */}
      <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-primary via-accent to-primary opacity-50"></div>
      
      <div className="container mx-auto px-4 md:px-6">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-16">
          
          {/* Brand Col */}
          <div className="lg:col-span-1">
            <a href="#" className="flex items-center gap-2 mb-6">
              <div className="w-8 h-8 rounded-lg bg-primary flex items-center justify-center text-primary-foreground">
                <Hexagon className="w-5 h-5" />
              </div>
              <span className="font-heading font-bold text-xl tracking-tight">
                ChemEng<span className="text-primary">.Edu</span>
              </span>
            </a>
            <p className="text-muted-foreground text-sm leading-relaxed mb-6">
              {/* REPLACE: Update footer description */}
              Advancing the frontiers of chemical engineering through rigorous research, innovative education, and global collaboration.
            </p>
            <div className="flex gap-4">
              <a href="#" className="text-muted-foreground hover:text-primary transition-colors">
                <Twitter className="w-5 h-5" />
              </a>
              <a href="#" className="text-muted-foreground hover:text-primary transition-colors">
                <Linkedin className="w-5 h-5" />
              </a>
              <a href="#" className="text-muted-foreground hover:text-primary transition-colors">
                <Youtube className="w-5 h-5" />
              </a>
              <a href="#" className="text-muted-foreground hover:text-primary transition-colors">
                <Github className="w-5 h-5" />
              </a>
            </div>
          </div>
          
          {/* Links Col 1 */}
          <div>
            <h3 className="font-bold font-heading mb-6">Academics</h3>
            <ul className="space-y-3">
              <li><a href="#" className="text-muted-foreground hover:text-primary text-sm transition-colors">Undergraduate Program</a></li>
              <li><a href="#" className="text-muted-foreground hover:text-primary text-sm transition-colors">Graduate Program</a></li>
              <li><a href="#" className="text-muted-foreground hover:text-primary text-sm transition-colors">Online Certificates</a></li>
              <li><a href="#" className="text-muted-foreground hover:text-primary text-sm transition-colors">Course Catalog</a></li>
              <li><a href="#" className="text-muted-foreground hover:text-primary text-sm transition-colors">Admissions</a></li>
            </ul>
          </div>
          
          {/* Links Col 2 */}
          <div>
            <h3 className="font-bold font-heading mb-6">Department</h3>
            <ul className="space-y-3">
              <li><a href="#" className="text-muted-foreground hover:text-primary text-sm transition-colors">Faculty Directory</a></li>
              <li><a href="#" className="text-muted-foreground hover:text-primary text-sm transition-colors">Research Centers</a></li>
              <li><a href="#" className="text-muted-foreground hover:text-primary text-sm transition-colors">News & Events</a></li>
              <li><a href="#" className="text-muted-foreground hover:text-primary text-sm transition-colors">Alumni Network</a></li>
              <li><a href="#" className="text-muted-foreground hover:text-primary text-sm transition-colors">Careers</a></li>
            </ul>
          </div>
          
          {/* Contact Col */}
          <div>
            <h3 className="font-bold font-heading mb-6">Contact Us</h3>
            <ul className="space-y-4">
              <li className="flex items-start gap-3">
                <MapPin className="w-5 h-5 text-primary flex-shrink-0 mt-0.5" />
                <span className="text-sm text-muted-foreground leading-relaxed">
                  {/* REPLACE: Update address */}
                  123 Engineering Building<br />
                  University Campus<br />
                  City, State 12345
                </span>
              </li>
              <li className="flex items-center gap-3">
                <Phone className="w-5 h-5 text-primary flex-shrink-0" />
                <span className="text-sm text-muted-foreground">+1 (555) 123-4567</span>
              </li>
              <li className="flex items-center gap-3">
                <Mail className="w-5 h-5 text-primary flex-shrink-0" />
                <a href="mailto:info@chemeng.edu" className="text-sm text-muted-foreground hover:text-primary transition-colors">
                  info@chemeng.edu
                </a>
              </li>
            </ul>
          </div>
          
        </div>
        
        <div className="border-t border-border/50 pt-8 flex flex-col md:flex-row justify-between items-center gap-4">
          <p className="text-sm text-muted-foreground">
            &copy; {new Date().getFullYear()} Chemical Engineering Department. All rights reserved.
          </p>
          <div className="flex gap-6">
            <a href="#" className="text-sm text-muted-foreground hover:text-primary transition-colors">Privacy Policy</a>
            <a href="#" className="text-sm text-muted-foreground hover:text-primary transition-colors">Terms of Service</a>
            <a href="#" className="text-sm text-muted-foreground hover:text-primary transition-colors">Accessibility</a>
          </div>
        </div>
      </div>
    </footer>
  );
}
