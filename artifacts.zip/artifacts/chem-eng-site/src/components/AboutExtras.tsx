import { motion } from 'framer-motion';
import { Clock, BarChart2, GraduationCap, ArrowRight } from 'lucide-react';
import { Link } from 'wouter';

export default function AboutExtras() {
  const cards = [
    {
      title: 'Kasaysayan',
      icon: Clock,
      description: 'Ang paglalakbay ng Chemical Engineering sa paglipas ng panahon.',
      link: '/timeline',
      linkText: 'Alamin ang Kasaysayan'
    },
    {
      title: 'Sahod',
      icon: BarChart2,
      description: 'Karaniwang kita sa propesyon ng Chemical Engineering.',
      link: '/statistics',
      linkText: 'Tingnan ang Kita'
    },
    {
      title: 'Kolehiyo',
      icon: GraduationCap,
      description: 'Mga unibersidad at kolehiyong nag-aalok ng Chemical Engineering.',
      link: '/universities',
      linkText: 'Tuklasin ang mga Kolehiyo'
    }
  ];

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: { staggerChildren: 0.15 }
    }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.5 } }
  };

  return (
    <section className="py-12 bg-background relative z-10">
      <div className="container mx-auto px-4 md:px-6">
        <motion.div
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-50px" }}
          className="grid grid-cols-1 md:grid-cols-3 gap-6"
        >
          {cards.map((card, index) => (
            <motion.div
              key={index}
              variants={itemVariants}
              whileHover={{ y: -6 }}
              className="glass-panel rounded-2xl p-6 flex flex-col items-start text-left h-full transition-all"
            >
              <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center text-primary mb-5">
                <card.icon className="w-6 h-6" />
              </div>
              <h3 className="text-xl font-bold font-heading mb-2">{card.title}</h3>
              <p className="text-muted-foreground mb-6 flex-grow">{card.description}</p>
              
              <div className="mt-auto">
                <Link href={card.link} className="inline-flex items-center text-sm font-medium text-primary hover:text-accent transition-colors group">
                  {card.linkText}
                  <ArrowRight className="w-4 h-4 ml-1 group-hover:translate-x-1 transition-transform" />
                </Link>
              </div>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
}