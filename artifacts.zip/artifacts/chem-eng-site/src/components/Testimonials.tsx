import { motion } from 'framer-motion';
import { User, Award } from 'lucide-react';

export default function Testimonials() {
  const testimonials = [
    {
      id: 1,
      // REPLACE: Update name, title, photo, and quote text
      name: "Engr. Maria Santos",
      title: "Process Engineer, PetroChem Inc.",
      quote: "The rigor of the curriculum and the direct access to cutting-edge research facilities completely transformed my approach to problem-solving. The faculty didn't just teach us engineering; they taught us how to pioneer new solutions.",
      badge: "PRC Licensed Chemical Engineer",
    }
  ];

  return (
    <section id="testimonials" className="py-24 bg-background">
      <div className="container mx-auto px-4 md:px-6">
        <div className="text-center max-w-2xl mx-auto mb-16">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
          >
            <span className="text-accent font-semibold tracking-wider uppercase text-sm">mula sa isang propesyonal</span>
            <h2 className="text-4xl font-bold font-heading mt-2 mb-4">Kwento ng Isang Chemical Engineer</h2>
            <p className="text-muted-foreground text-lg">Alamin ang mga karanasan, hamon, at tagumpay ng isang Chemical Engineer sa kaniyang paglalakbay sa propesyon.</p>
          </motion.div>
        </div>

        <div className="max-w-3xl mx-auto space-y-8">
          {testimonials.map((item, index) => (
            <motion.div
              key={item.id}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              className="flex flex-col md:flex-row items-center md:items-start gap-8 p-8 md:p-10 rounded-3xl bg-gradient-to-br from-primary/5 to-accent/5 border border-accent/20 relative"
            >
              {/* Profile Photo Placeholder */}
              <div className="flex-shrink-0">
                <div className="w-[100px] h-[100px] rounded-full bg-gradient-to-br from-primary/20 to-accent/20 flex items-center justify-center border-2 border-background shadow-md">
                  {/* REPLACE: with actual <img> tag when available */}
                  <User className="w-10 h-10 text-primary/50" />
                </div>
              </div>

              <div className="flex-grow text-center md:text-left relative">
                {/* Decorative Quote Mark */}
                <div className="absolute -top-6 -left-4 md:-top-4 md:-left-8 text-6xl font-serif text-accent/20 select-none">
                  "
                </div>
                
                <p className="text-lg md:text-xl font-medium leading-relaxed text-foreground/90 mb-6 relative z-10 italic">
                  {item.quote}
                </p>
                
                <div>
                  <h4 className="font-bold font-heading text-lg">{item.name}</h4>
                  <p className="text-muted-foreground text-sm mb-3">{item.title}</p>
                  <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-primary/10 text-primary text-xs font-semibold">
                    <Award className="w-3.5 h-3.5" />
                    {item.badge}
                  </div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}