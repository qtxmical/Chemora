import { motion } from 'framer-motion';
import { MapPin, ExternalLink, CheckCircle2 } from 'lucide-react';

export default function Universities() {
  // REPLACE: Update university data with actual links and precise details if necessary
  const universities = [
    {
      name: "University of the Philippines Diliman",
      url: "#",
      location: "Quezon City, Metro Manila",
      tuition: "Free (State Univ)",
      duration: "4-5 years",
      chedRecognized: true,
      boardPassRate: "95%+",
      notable: "Center of Excellence in Chemical Engineering",
    },
    {
      name: "De La Salle University",
      url: "#",
      location: "Malate, Manila",
      tuition: "₱70,000–₱90,000/sem",
      duration: "4 years",
      chedRecognized: true,
      boardPassRate: "90%+",
      notable: "Known for strong research and industry linkages",
    },
    {
      name: "University of Santo Tomas",
      url: "#",
      location: "Sampaloc, Manila",
      tuition: "₱50,000–₱70,000/sem",
      duration: "4 years",
      chedRecognized: true,
      boardPassRate: "85%+",
      notable: "Oldest existing university in Asia with extensive lab facilities",
    },
    {
      name: "Mapúa University",
      url: "#",
      location: "Intramuros, Manila",
      tuition: "₱35,000–₱50,000/term",
      duration: "3-4 years (Quarterm)",
      chedRecognized: true,
      boardPassRate: "80%+",
      notable: "ABET-accredited engineering programs",
    },
    {
      name: "University of San Carlos",
      url: "#",
      location: "Cebu City, Cebu",
      tuition: "₱40,000–₱50,000/sem",
      duration: "4-5 years",
      chedRecognized: true,
      boardPassRate: "85%+",
      notable: "Premier engineering school in the Visayas region",
    },
    {
      name: "Ateneo de Manila University",
      url: "#",
      location: "Quezon City, Metro Manila",
      tuition: "₱80,000–₱100,000/sem",
      duration: "4-5 years",
      chedRecognized: true,
      boardPassRate: "90%+",
      notable: "Strong focus on environmental and materials engineering",
    }
  ];

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: { staggerChildren: 0.1 }
    }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.5 } }
  };

  return (
    <section id="universities" className="py-24 relative bg-muted/30">
      <div className="container mx-auto px-4 md:px-6">
        <div className="text-center max-w-2xl mx-auto mb-16">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
          >
            <span className="text-primary font-semibold tracking-wider uppercase text-sm">Top Philippine Universities</span>
            <h2 className="text-4xl font-bold font-heading mt-2 mb-4">Where to Study Chemical Engineering</h2>
            <p className="text-muted-foreground text-lg">
              Explore leading institutions offering premier Chemical Engineering education and research opportunities.
            </p>
          </motion.div>
        </div>

        <motion.div 
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-50px" }}
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
        >
          {universities.map((uni, index) => (
            <motion.div 
              key={index}
              variants={itemVariants}
              whileHover={{ y: -5 }}
              className="glass-panel rounded-2xl p-6 relative group transition-all duration-300 hover:shadow-xl hover:shadow-primary/5 hover:border-primary/30 flex flex-col h-full"
            >
              <div className="mb-4 flex justify-between items-start gap-4">
                <a 
                  href={uni.url} 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="font-bold font-heading text-xl leading-tight group-hover:text-primary transition-colors flex items-start gap-1"
                >
                  {uni.name}
                  <ExternalLink className="w-4 h-4 mt-1 flex-shrink-0 opacity-0 group-hover:opacity-100 transition-opacity" />
                </a>
              </div>

              <div className="space-y-3 mb-6 flex-grow">
                <div className="flex items-center text-sm text-muted-foreground">
                  <MapPin className="w-4 h-4 mr-2 flex-shrink-0" />
                  {uni.location}
                </div>
                
                <div className="flex flex-wrap gap-2 mt-3">
                  <span className="inline-flex items-center px-2.5 py-1 rounded-md bg-secondary text-secondary-foreground text-xs font-medium">
                    {uni.duration}
                  </span>
                  <span className="inline-flex items-center px-2.5 py-1 rounded-md border border-border text-xs font-medium">
                    {uni.tuition}
                  </span>
                  {uni.chedRecognized && (
                    <span className="inline-flex items-center px-2.5 py-1 rounded-md bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 text-xs font-medium border border-emerald-500/20">
                      <CheckCircle2 className="w-3 h-3 mr-1" />
                      CHED Recognized
                    </span>
                  )}
                </div>
              </div>

              <div className="pt-4 border-t border-border/50">
                <div className="flex justify-between items-center mb-2">
                  <span className="text-xs text-muted-foreground uppercase font-semibold tracking-wider">Board Pass Rate</span>
                  <span className="text-sm font-bold text-foreground">{uni.boardPassRate}</span>
                </div>
                <p className="text-sm text-muted-foreground italic line-clamp-2">
                  {uni.notable}
                </p>
              </div>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
}