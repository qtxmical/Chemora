import { motion } from 'framer-motion';
import { ExternalLink, FileText } from 'lucide-react';

export default function References() {
  // REPLACE: Update publications
  const publications = [
    {
      authors: "Smith, J. A., Doe, R., & Chen, W.",
      year: "2023",
      title: "Advanced catalytic mechanisms in organic synthesis via computational modeling",
      journal: "Journal of the American Chemical Society",
      volume: "145(2)",
      pages: "123-145",
      doi: "10.1021/jacs.12345"
    },
    {
      authors: "Johnson, M., et al.",
      year: "2023",
      title: "Scalable synthesis of mesoporous silica nanoparticles for targeted drug delivery",
      journal: "Advanced Materials",
      volume: "35(14)",
      pages: "2201456",
      doi: "10.1002/adma.202201456"
    },
    {
      authors: "Williams, E., & Brown, T.",
      year: "2022",
      title: "Electrochemical reduction of CO2 using nanostructured copper catalysts",
      journal: "Nature Energy",
      volume: "7(5)",
      pages: "415-422",
      doi: "10.1038/s41560-022-1234-5"
    },
    {
      authors: "Garcia, L., Smith, J. A., & Patel, N.",
      year: "2022",
      title: "Thermodynamic analysis of novel molten salt systems for concentrated solar power",
      journal: "Chemical Engineering Science",
      volume: "248",
      pages: "117205",
      doi: "10.1016/j.ces.2022.117205"
    }
  ];

  return (
    <section id="references" className="py-24 bg-muted/30">
      <div className="container mx-auto px-4 md:px-6">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-16">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5 }}
            >
              <span className="text-primary font-semibold tracking-wider uppercase text-sm">Publications</span>
              <h2 className="text-4xl font-bold font-heading mt-2 mb-4">Selected Recent Work</h2>
              <p className="text-muted-foreground text-lg">
                {/* REPLACE: Update description */}
                Highlighted peer-reviewed publications from our faculty and graduate researchers over the past academic year.
              </p>
            </motion.div>
          </div>

          <div className="space-y-6">
            {publications.map((pub, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                className="glass-panel p-6 rounded-2xl border-l-4 border-l-primary flex flex-col sm:flex-row gap-4 sm:items-start group hover:shadow-md transition-all"
              >
                <div className="flex-shrink-0 mt-1">
                  <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center text-primary group-hover:bg-primary group-hover:text-primary-foreground transition-colors">
                    <FileText className="w-5 h-5" />
                  </div>
                </div>
                
                <div className="flex-grow">
                  <p className="text-sm font-medium text-muted-foreground mb-1">
                    {pub.authors} ({pub.year})
                  </p>
                  <h3 className="text-lg font-bold font-heading leading-snug mb-2 group-hover:text-primary transition-colors">
                    {pub.title}
                  </h3>
                  <p className="text-sm text-foreground/80 font-serif italic mb-3">
                    {pub.journal}, {pub.volume}, {pub.pages}.
                  </p>
                  <div className="flex gap-4 text-sm">
                    <a href="#" className="inline-flex items-center text-primary hover:underline">
                      DOI: {pub.doi} <ExternalLink className="w-3 h-3 ml-1" />
                    </a>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
          
          <div className="mt-12 text-center">
            <a 
              href="#" 
              className="inline-flex items-center justify-center rounded-xl border border-input bg-background/50 backdrop-blur-sm px-6 py-3 text-sm font-medium text-foreground hover:bg-accent/10 hover:text-accent-foreground transition-all"
            >
              View Full Publication Archive
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}
