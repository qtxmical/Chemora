import { motion, useInView } from 'framer-motion';
import { useRef, useEffect, useState } from 'react';
import { Users, FlaskConical, Award, Globe, BarChart2 } from 'lucide-react';

function Counter({ end, suffix = "", duration = 2 }: { end: number; suffix?: string; duration?: number }) {
  const [count, setCount] = useState(0);
  const ref = useRef<HTMLSpanElement>(null);
  const isInView = useInView(ref, { once: true, margin: "-50px" });

  useEffect(() => {
    if (!isInView) return;

    let startTime: number | null = null;
    let animationFrame: number;

    const animate = (timestamp: number) => {
      if (!startTime) startTime = timestamp;
      const progress = (timestamp - startTime) / (duration * 1000);

      if (progress < 1) {
        // Easing function: easeOutQuart
        const easeOut = 1 - Math.pow(1 - progress, 4);
        setCount(Math.floor(end * easeOut));
        animationFrame = requestAnimationFrame(animate);
      } else {
        setCount(end);
      }
    };

    animationFrame = requestAnimationFrame(animate);

    return () => cancelAnimationFrame(animationFrame);
  }, [end, duration, isInView]);

  return (
    <span ref={ref}>
      {count}{suffix}
    </span>
  );
}

function ChartSlot({ src, alt = '', title }: { src?: string; alt?: string; title?: string }) {
  return (
    <div className="bg-black/20 backdrop-blur-md rounded-2xl overflow-hidden border border-white/10 h-full flex flex-col">
      {title && <div className="px-6 pt-5 pb-3 text-lg font-semibold font-heading text-primary-foreground">{title}</div>}
      {src ? (
        <img src={src} alt={alt} className="w-full h-auto object-cover flex-grow" />
      ) : (
        <div className="flex flex-col items-center justify-center gap-3 py-16 px-8 border-2 border-dashed border-white/20 rounded-2xl m-4 text-primary-foreground/60 flex-grow">
          <BarChart2 className="w-12 h-12 opacity-40" />
          <p className="text-sm text-center">// REPLACE: Insert chart image here</p>
        </div>
      )}
    </div>
  );
}

export default function Statistics() {
  const stats = [
    { label: 'Faculty Members', value: 45, suffix: '+', icon: Users },
    { label: 'Research Labs', value: 32, suffix: '', icon: FlaskConical },
    { label: 'Patents Issued', value: 120, suffix: '+', icon: Award },
    { label: 'Global Partners', value: 85, suffix: '', icon: Globe },
  ];

  return (
    <section id="statistics" className="py-24 relative overflow-hidden bg-primary text-primary-foreground">
      {/* Background elements */}
      <div className="absolute inset-0 opacity-10">
        <svg className="h-full w-full" xmlns="http://www.w3.org/2000/svg">
          <defs>
            <pattern id="hexagons" width="50" height="43.4" patternUnits="userSpaceOnUse" patternTransform="scale(2)">
              <path d="M25,0L50,14.5L50,43.4L25,57.8L0,43.4L0,14.5Z" fill="none" stroke="currentColor" strokeWidth="1"/>
            </pattern>
          </defs>
          <rect width="100%" height="100%" fill="url(#hexagons)" />
        </svg>
      </div>

      <div className="container mx-auto px-4 md:px-6 relative z-10">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8 md:gap-12 mb-20">
          {stats.map((stat, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              className="text-center"
            >
              <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-white/10 mb-6 backdrop-blur-sm">
                <stat.icon className="w-8 h-8 text-accent" />
              </div>
              <div className="text-5xl md:text-6xl font-bold font-heading mb-2">
                <Counter end={stat.value} suffix={stat.suffix} />
              </div>
              <div className="text-primary-foreground/80 font-medium tracking-wide uppercase text-sm">
                {stat.label}
              </div>
            </motion.div>
          ))}
        </div>

        {/* Charts Section */}
        <div className="mt-16">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-10"
          >
            <h3 className="text-3xl font-bold font-heading mb-4">Research Impact Data</h3>
            <p className="text-primary-foreground/80 max-w-2xl mx-auto">
              Visualizing our growth, publications, and funding metrics over the past decade.
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.1 }}
              className="h-full"
            >
              {/* REPLACE: Provide src string with actual chart image */}
              <ChartSlot title="Annual Research Funding ($M)" />
            </motion.div>
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.2 }}
              className="h-full"
            >
              {/* REPLACE: Provide src string with actual chart image */}
              <ChartSlot title="Publications by Focus Area" />
            </motion.div>
          </div>
        </div>
      </div>
    </section>
  );
}
