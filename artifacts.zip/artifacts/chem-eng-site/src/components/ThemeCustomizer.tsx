import { useState, useEffect } from 'react';
import { Settings, X } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { useTheme } from 'next-themes';

// Helper to convert hex to HSL variables string
function hexToHSL(hex: string): string {
  let r = 0, g = 0, b = 0;
  if (hex.length === 4) {
    r = parseInt(hex[1] + hex[1], 16);
    g = parseInt(hex[2] + hex[2], 16);
    b = parseInt(hex[3] + hex[3], 16);
  } else if (hex.length === 7) {
    r = parseInt(hex.substring(1, 3), 16);
    g = parseInt(hex.substring(3, 5), 16);
    b = parseInt(hex.substring(5, 7), 16);
  }
  
  r /= 255;
  g /= 255;
  b /= 255;
  const max = Math.max(r, g, b), min = Math.min(r, g, b);
  let h = 0, s = 0, l = (max + min) / 2;

  if (max !== min) {
    const d = max - min;
    s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
    switch (max) {
      case r: h = (g - b) / d + (g < b ? 6 : 0); break;
      case g: h = (b - r) / d + 2; break;
      case b: h = (r - g) / d + 4; break;
    }
    h /= 6;
  }

  return `${Math.round(h * 360)} ${Math.round(s * 100)}% ${Math.round(l * 100)}%`;
}

export default function ThemeCustomizer() {
  const [isOpen, setIsOpen] = useState(false);
  const { theme, setTheme } = useTheme();
  
  const [primaryColor, setPrimaryColor] = useState('#1e40af'); // Steel Blue approx
  const [accentColor, setAccentColor] = useState('#f59e0b'); // Amber approx
  const [headingFont, setHeadingFont] = useState('Montserrat');
  const [bodyFont, setBodyFont] = useState('Inter');
  const [borderRadius, setBorderRadius] = useState('0.75rem');

  // Apply CSS variable changes
  useEffect(() => {
    const root = document.documentElement;
    root.style.setProperty('--primary', hexToHSL(primaryColor));
    root.style.setProperty('--accent', hexToHSL(accentColor));
    root.style.setProperty('--font-heading', `'${headingFont}', sans-serif`);
    root.style.setProperty('--font-body', `'${bodyFont}', sans-serif`);
    root.style.setProperty('--radius', borderRadius);
  }, [primaryColor, accentColor, headingFont, bodyFont, borderRadius]);

  return (
    <>
      <button
        onClick={() => setIsOpen(true)}
        className="fixed bottom-6 left-6 z-50 p-3 rounded-full bg-secondary text-secondary-foreground shadow-lg border border-border hover:bg-secondary/80 transition-colors focus:outline-none focus:ring-2 focus:ring-primary focus:ring-offset-2 focus:ring-offset-background"
        aria-label="Open Theme Customizer"
      >
        <Settings className="w-5 h-5 animate-[spin_4s_linear_infinite]" />
      </button>

      <AnimatePresence>
        {isOpen && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsOpen(false)}
              className="fixed inset-0 z-50 bg-background/50 backdrop-blur-sm"
            />
            <motion.div
              initial={{ x: '100%' }}
              animate={{ x: 0 }}
              exit={{ x: '100%' }}
              transition={{ type: 'spring', damping: 25, stiffness: 200 }}
              className="fixed top-0 right-0 bottom-0 z-50 w-full max-w-sm bg-card border-l border-border shadow-2xl p-6 overflow-y-auto"
            >
              <div className="flex items-center justify-between mb-8">
                <h2 className="text-xl font-bold font-heading">Theme Customizer</h2>
                <button
                  onClick={() => setIsOpen(false)}
                  className="p-2 rounded-full hover:bg-muted transition-colors text-muted-foreground hover:text-foreground"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div className="space-y-6">
                {/* Mode Toggle */}
                <div>
                  <label className="block text-sm font-medium mb-2">Mode</label>
                  <div className="grid grid-cols-2 gap-2">
                    <button
                      onClick={() => setTheme('light')}
                      className={`py-2 px-4 rounded-md border text-sm font-medium transition-colors ${
                        theme === 'light' ? 'bg-primary text-primary-foreground border-primary' : 'bg-background hover:bg-muted border-input'
                      }`}
                    >
                      Light
                    </button>
                    <button
                      onClick={() => setTheme('dark')}
                      className={`py-2 px-4 rounded-md border text-sm font-medium transition-colors ${
                        theme === 'dark' ? 'bg-primary text-primary-foreground border-primary' : 'bg-background hover:bg-muted border-input'
                      }`}
                    >
                      Dark
                    </button>
                  </div>
                </div>

                {/* Colors */}
                <div>
                  <label className="block text-sm font-medium mb-2">Colors</label>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-muted-foreground">Primary</span>
                      <input
                        type="color"
                        value={primaryColor}
                        onChange={(e) => setPrimaryColor(e.target.value)}
                        className="h-8 w-14 cursor-pointer rounded bg-transparent p-0"
                      />
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-muted-foreground">Accent</span>
                      <input
                        type="color"
                        value={accentColor}
                        onChange={(e) => setAccentColor(e.target.value)}
                        className="h-8 w-14 cursor-pointer rounded bg-transparent p-0"
                      />
                    </div>
                  </div>
                </div>

                {/* Typography */}
                <div>
                  <label className="block text-sm font-medium mb-2">Typography</label>
                  <div className="space-y-3">
                    <div>
                      <span className="text-sm text-muted-foreground block mb-1">Heading Font</span>
                      <select
                        value={headingFont}
                        onChange={(e) => setHeadingFont(e.target.value)}
                        className="w-full rounded-md border border-input bg-background px-3 py-2 text-sm focus:ring-2 focus:ring-primary focus:outline-none"
                      >
                        <option value="Montserrat">Montserrat</option>
                        <option value="Inter">Inter</option>
                        <option value="Outfit">Outfit</option>
                        <option value="Playfair Display">Playfair Display</option>
                      </select>
                    </div>
                    <div>
                      <span className="text-sm text-muted-foreground block mb-1">Body Font</span>
                      <select
                        value={bodyFont}
                        onChange={(e) => setBodyFont(e.target.value)}
                        className="w-full rounded-md border border-input bg-background px-3 py-2 text-sm focus:ring-2 focus:ring-primary focus:outline-none"
                      >
                        <option value="Inter">Inter</option>
                        <option value="Outfit">Outfit</option>
                        <option value="Montserrat">Montserrat</option>
                      </select>
                    </div>
                  </div>
                </div>

                {/* Border Radius */}
                <div>
                  <label className="block text-sm font-medium mb-2">Border Radius</label>
                  <div className="grid grid-cols-3 gap-2">
                    {[
                      { label: '0', value: '0rem' },
                      { label: '0.5', value: '0.5rem' },
                      { label: '0.75', value: '0.75rem' },
                      { label: '1.0', value: '1rem' },
                      { label: '1.5', value: '1.5rem' },
                      { label: 'Full', value: '9999px' },
                    ].map((radius) => (
                      <button
                        key={radius.label}
                        onClick={() => setBorderRadius(radius.value)}
                        className={`py-2 px-2 text-xs rounded-md border font-medium transition-colors ${
                          borderRadius === radius.value ? 'bg-primary text-primary-foreground border-primary' : 'bg-background hover:bg-muted border-input'
                        }`}
                      >
                        {radius.label}
                      </button>
                    ))}
                  </div>
                </div>

                <div className="pt-4 border-t border-border mt-6">
                  <p className="text-xs text-muted-foreground italic text-center">
                    Note: Changes applied here are temporary and will reset on page reload. To make permanent changes, update the CSS variables in index.css.
                  </p>
                </div>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </>
  );
}
