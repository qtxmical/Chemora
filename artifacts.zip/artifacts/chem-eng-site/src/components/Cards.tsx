import { motion } from 'framer-motion';
import { BookOpen, Activity, Leaf, Zap } from 'lucide-react';
import { Link } from 'wouter';

export default function Cards() {
  // REPLACE: Update these card items with actual research areas or departments
  const areas = [
    {
      title: 'Industriya',
      slug: 'industriya',
      description: 'Mga larangang gumagamit ng Chemical Engineering.',
      icon: Activity,
      color: 'text-blue-500',
      bg: 'bg-blue-500/10',
    },
    {
      title: 'Proseso',
      slug: 'proseso',
      description: 'Paano ginagawang produkto ang mga ideya at materyales.',
      icon: Zap,
      color: 'text-amber-500',
      bg: 'bg-amber-500/10',
    },
    {
      title: 'Inobasyon',
      slug: 'inobasyon',
      description: 'Mga solusyong hinuhubog ng agham at teknolohiya.',
      icon: BookOpen,
      color: 'text-purple-500',
      bg: 'bg-purple-500/10',
    },
    {
      title: 'Kasanayan',
      slug: 'kasanayan',
      description: 'Mga kakayahang kailangan upang maging Chemical Engineer.',
      icon: Leaf,
      color: 'text-emerald-500',
      bg: 'bg-emerald-500/10',
    },
  ];

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: { staggerChildren: 0.15 }
    }
  };

  const cardVariants = {
    hidden: { opacity: 0, y: 30 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.6 } }
  };

  return (
    <section id="research" className="py-24 bg-muted/30 relative">
      <div className="container mx-auto px-4 md:px-6">
        <div className="text-center max-w-2xl mx-auto mb-16">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
          >
            <span className="text-primary font-semibold tracking-wider uppercase text-sm">Focus Areas</span>
            <h2 className="text-4xl font-bold font-heading mt-2 mb-4">Core Research Domains</h2>
            <p className="text-muted-foreground text-lg">
              {/* REPLACE: Update description */}
              Our department drives innovation across four critical domains shaping the future of global industry and sustainability.
            </p>
          </motion.div>
        </div>

        <motion.div 
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-50px" }}
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6"
        >
          {areas.map((area, index) => (
            <motion.div 
              key={index} 
              variants={cardVariants}
              whileHover={{ y: -10, transition: { duration: 0.2 } }}
              className="glass-panel rounded-2xl p-8 relative overflow-hidden group hover:shadow-xl hover:shadow-primary/5 transition-all"
            >
              {/* Hover glow effect */}
              <div className={`absolute top-0 right-0 w-32 h-32 opacity-0 group-hover:opacity-100 transition-opacity duration-500 rounded-full blur-3xl -mr-16 -mt-16 ${area.bg}`}></div>
              
              <div className={`w-14 h-14 rounded-xl ${area.bg} ${area.color} flex items-center justify-center mb-6 relative z-10`}>
                <area.icon className="w-7 h-7" />
              </div>
              
              <h3 className="text-xl font-bold font-heading mb-3 relative z-10">{area.title}</h3>
              <p className="text-muted-foreground leading-relaxed relative z-10">{area.description}</p>
              
              <div className="mt-6 pt-6 border-t border-border/50 relative z-10">
                <Link href={`/research/${area.slug}`} className="inline-flex items-center text-sm font-medium text-primary hover:text-accent transition-colors">
                  Alamin Pa
                  <svg className="w-4 h-4 ml-1 group-hover:translate-x-1 transition-transform" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                  </svg>
                </Link>
              </div>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
}
