import { motion } from 'framer-motion';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

export default function FAQ() {
  // REPLACE: Update FAQ content
  const faqs = [
    {
      question: "Ano ang pinagkaiba ng Chemical Engineer at Chemist?",
      answer: "Ang Chemist ay nakatuon sa pag-aaral ng mga katangian, komposisyon, at reaksyon ng mga sangkap, habang ang Chemical Engineer ay gumagamit ng kaalamang ito upang magdisenyo, magpalawak, at magpatakbo ng mga proseso para makagawa ng produkto sa mas malaking antas."
    },
    {
      question: "Ano ang karaniwang ginagawa ng isang Chemical Engineer?",
      answer: "Ang isang Chemical Engineer ay maaaring magdisenyo ng mga proseso, magsuri ng produksyon, magpaunlad ng mga produkto, at maghanap ng paraan upang mapabuti ang kaligtasan at kahusayan ng mga operasyon sa industriya. Maaari silang magtrabaho sa mga larangan tulad ng pagkain, parmasya, enerhiya, at pangangalaga sa kapaligiran."
    },
    {
      question: "Paano maging Chemical Engineer?",
      answer: "Para maging Chemical Engineer, kailangang kumuha ng Bachelor of Science in Chemical Engineering (BS ChE) sa kolehiyo at makumpleto ang kinakailangang pagsasanay at pagsusulit para maging lisensyadong inhinyero. Bilang estudyante ng Grade 10 o Senior High School, makatutulong ang pagpapatibay ng kaalaman sa Matematika, Agham, at paglutas ng problema."
    },
    {
      question: "Anong mga kumpanya o industriya ang kumukuha ng Chemical Engineer?",
      answer: "Ang mga Chemical Engineer ay maaaring magtrabaho sa iba't ibang kumpanya at industriya tulad ng pagkain at inumin, parmasya, petrolyo at enerhiya, pagmamanupaktura, water treatment, at environmental industries. Maaari silang mapunta sa mga larangan ng production, research and development, quality control, process design, at operations management."
    },
    {
      question: "Mahirap ba ang Chemical Engineering?",
      answer: "Tulad ng ibang kursong inhinyeriya, ang Chemical Engineering ay isang mapanghamong programa dahil pinag-aaralan dito ang matematika, agham, at mga komplikadong proseso. Gayunpaman, sa pamamagitan ng sipag, tamang pag-aaral, at interes sa paglutas ng problema, kayang makamit ng mga estudyante ang kanilang layunin bilang Chemical Engineer."
    },
    {
      question: "Kailangan ba na mahusay ako sa Chemistry para kumuha ng Chemical Engineering?",
      answer: "Hindi kailangang maging eksperto agad sa Chemistry bago kumuha ng Chemical Engineering, ngunit mahalaga ang interes at kahandaang matuto tungkol sa agham at matematika. Sa kurso, mas mapapalalim ang kaalaman sa Chemistry habang ginagamit ito kasama ng mga prinsipyo ng inhinyeriya upang makabuo ng praktikal na solusyon."
    }
  ];

  return (
    <section id="faq" className="py-24">
      <div className="container mx-auto px-4 md:px-6">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12">
          
          <div className="lg:col-span-5">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5 }}
              className="sticky top-32"
            >
              <span className="text-primary font-semibold tracking-wider uppercase text-sm">may katanungan?</span>
              <h2 className="text-4xl font-bold font-heading mt-2 mb-6">Frequently Asked Questions</h2>
              <p className="text-muted-foreground text-lg mb-8">
                {/* REPLACE: Update description */}
                Find answers to common questions about our programs, research opportunities, and admissions process. Can't find what you're looking for? Reach out to our admissions office.
              </p>
              
              <a 
                href="#contact" 
                className="inline-flex items-center justify-center rounded-xl bg-secondary px-6 py-3 text-sm font-medium text-secondary-foreground hover:bg-secondary/80 transition-colors"
              >
                Contact Admissions
              </a>
            </motion.div>
          </div>

          <div className="lg:col-span-7">
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: 0.2 }}
            >
              <Accordion type="single" collapsible className="w-full space-y-4">
                {faqs.map((faq, index) => (
                  <AccordionItem 
                    key={index} 
                    value={`item-${index}`}
                    className="glass-panel border-border/50 rounded-xl px-2 data-[state=open]:border-primary/30 transition-colors"
                  >
                    <AccordionTrigger className="hover:no-underline py-5 px-4 text-left font-semibold text-lg">
                      {faq.question}
                    </AccordionTrigger>
                    <AccordionContent className="px-4 pb-5 text-muted-foreground leading-relaxed">
                      {faq.answer}
                    </AccordionContent>
                  </AccordionItem>
                ))}
              </Accordion>
            </motion.div>
          </div>
          
        </div>
      </div>
    </section>
  );
}
