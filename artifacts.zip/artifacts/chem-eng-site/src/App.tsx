import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import { Route, Switch, Router as WouterRouter } from 'wouter';
import { ThemeProvider } from 'next-themes';
import Home from '@/pages/Home';
import ResearchArea from '@/pages/ResearchArea';
import TimelinePage from '@/pages/TimelinePage';
import StatisticsPage from '@/pages/StatisticsPage';
import UniversitiesPage from '@/pages/UniversitiesPage';

const queryClient = new QueryClient();

function App() {
  return (
    <ThemeProvider attribute="class" defaultTheme="light" enableSystem>
      <QueryClientProvider client={queryClient}>
        <TooltipProvider>
          <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, '')}>
            <Switch>
              <Route path="/" component={Home} />
              <Route path="/research/:slug" component={ResearchArea} />
              <Route path="/timeline" component={TimelinePage} />
              <Route path="/statistics" component={StatisticsPage} />
              <Route path="/universities" component={UniversitiesPage} />
            </Switch>
          </WouterRouter>
          <Toaster />
        </TooltipProvider>
      </QueryClientProvider>
    </ThemeProvider>
  );
}

export default App;
